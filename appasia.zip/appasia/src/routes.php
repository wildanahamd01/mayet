<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;

return function (App $app) {
    $container = $app->getContainer();
    /*
    $app->get('/[{name}]', function (Request $request, Response $response, array $args) use ($container) {
        // Sample log message
        $container->get('logger')->info("Slim-Skeleton '/' route");

        // Render index view
        return $container->get('renderer')->render($response, 'index.phtml', $args);
    });
    */
  
	//--Tampil data semua siswa
	//$app->get("/studentterserah", function (Request $request, Response $response){
	//	$id=$_GET['id'];
	//    $sql = "SELECT * FROM terserah where terserah_id='$id'";
	//    $stmt = $this->db->prepare($sql);
	//    $stmt->execute();
	//    $result = $stmt->fetchAll();
	//    return $response->withJson(["status" => "success", "data" => $result], 200);
	//});

	$app->get("/staff", function (Request $request, Response $response){
	    $sql = "SELECT * FROM staff";
	    $stmt = $this->db->prepare($sql);
	    $stmt->execute();
	    $result = $stmt->fetchAll();
		return $response->withJson(["Request Data" => "Success.", "This is your data : " => $result], 200);
		json_encode($response);
	});
	//--tanpil siswa menurut ID siswa
	//$app->get("/studentscri/{id}", function (Request $request, Response $response, $args){
	//    $id = $args["id"];
	//    $sql = "SELECT * FROM student WHERE student_id=:id";
	//    $stmt = $this->db->prepare($sql);
	//    $stmt->execute([":id" => $id]);
	//    $result = $stmt->fetch();
	//    return $response->withJson(["status" => "success", "data" => $result], 200);
	//});
	//--update data siswa menurut ID
	//$app->get("/studentsedit", function (Request $request, Response $response, $args){
	//    $id = $_GET["id"];
	//	$nama = $_GET["nama"];
	//	$alamat = $_GET["alamat"];
	//    $new_student = $request->getParsedBody();
	//    $sql = "UPDATE terserah SET terserah_nama=:sName, terserah_opo=:sAddress WHERE terserah_id=:id";
	//    $stmt = $this->db->prepare($sql);
	    
	//    $data = [
	//        ":id" => $id,
	//        ":sName" => $nama,
	//        ":sAddress" => $alamat
	//    ];

	//	if($stmt->execute($data))
	//	return $response->withHeader('location','http://localhost/slimtembak/index.php');
	       //return $response->withJson(["status" => "success", "data" => "1"], 200);
	    
	    //return $response->withJson(["status" => "failed", "data" => "0"], 200);
	//});
	// dellete
	//$app->get("/studentsdel", function (Request $request, Response $response){
		//$id = $args["id"];
	//	$id=$_GET['id'];
	//    $sql = "DELETE FROM terserah WHERE terserah_id=:id";
	//	    $stmt = $this->db->prepare($sql);
	    
	//    $data = [
	//        ":id" => $id
	//    ];

	//    if($stmt->execute($data))
	//	   return $response->withHeader('location','location:http://localhost/slimtembak/');
		   //header("location:http://localhost/slimtembak/");
		   //return("http://localhost/slimtembak/");
	    //return $response->withJson(["status" => "failed", "data" => "0"], 200);
	//});

	//function index_delete() {
    //    $id = $this->delete('id');
    //    $this->db->where('id', $id);
    //    $delete = $this->db->delete('telepon');
    //    if ($delete) {
    //        $this->response(array('status' => 'success'), 201);
    //    } else {
    //        $this->response(array('status' => 'fail', 502));
    //    }
    //}
	//$app->delete("/studentsdel", function (Request $request, Response $response, $args){
	//		$id = $_GET['id'];
	//		$id2 = $args["id"];
	//	    $sql = "DELETE FROM student WHERE student_id='$id'";
	//	    $stmt = $this->db->prepare($sql);
	//		$stmt->execute();
	//		$result = $stmt->fetchAll();
	//	    if($stmt->execute())
	//		return $response->withJson(["status" => "success", "data" => $result], 200);	    
	//	    return $response->withJson(["status" => "failed", "data" => "0"], 200);
	//	});
};
