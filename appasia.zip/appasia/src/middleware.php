<?php

use Slim\App;

return function (App $app) {
    // e.g: $app->add(new \Slim\Csrf\Guard);
    //--validasi API Key
	$app->add(function ($request, $response, $next) {
	    $key = $request->getQueryParam("req");

	    if(!isset($key)){
	        return $response->withJson(["API Key" => "Required"], 401);
	    }
	    
	    $sql = "SELECT * FROM keyapi WHERE keyapi_key='".$key."'"; 
	    $stmt = $this->db->prepare($sql);
	    $stmt->execute([":keyapi_key" => $key]);
	    
	    if($stmt->rowCount() > 0){
	        $result = $stmt->fetch();
	        if($key == $result["keyapi_key"]){
	        
	            // update hit
	            $sql = "UPDATE keyapi SET keyapi_hit=keyapi_hit+1 WHERE keyapi_key=:keyapi_key";
	            $stmt = $this->db->prepare($sql);
	            $stmt->execute([":keyapi_key" => $key]);
	            
	            return $response = $next($request, $response);
	        }
	    }
	    return $response->withJson(["status" => "Unauthorized"], 401);
	});
};
